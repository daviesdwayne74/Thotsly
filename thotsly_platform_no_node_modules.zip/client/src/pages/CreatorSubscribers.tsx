import React from 'react';

const CreatorSubscribers: React.FC = () => {
  return <div>Creator Subscribers Page</div>;
};

export default CreatorSubscribers;
