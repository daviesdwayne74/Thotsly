import React from 'react';

const UserProfile: React.FC = () => {
  return <div>UserProfile Page</div>;
};

export default UserProfile;
